# pyJoiner - Windows Version
# Coder: Daniel Henrique Negri Moreno (a.k.a W1ckerMan)

How to run pyJoiner:

1 - pyJoiner must run ONLY UNDER Windows platform.


2 - Please install Python 3.4.4 
https://www.python.org/downloads/release/python-344/


3 - You need manual installation of pyinstaller. 
Run 'pip install pyinstaller' in cmd.exe

4 - After run pyJoiner.py, the file "py_file.pyw" (containing the 
source code responsible to Join and run files) will be created.

5 - After run pyJoiner, the directory "output" (containing the 
file "py_file.exe") will be created.
